import React from 'react';
import Header from './Header';
import Content from './Content';

import 'bootstrap/dist/css/bootstrap.min.css';

function Detail (){
  
    return(
    <main className="main">
      <Header/>
      <Content/>
    </main>);
  
}

export default Detail;
