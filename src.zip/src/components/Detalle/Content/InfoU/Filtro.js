
import React from 'react'

function Filtro(){
    return(<div class="Filtrado">
        <hr class="linea"></hr>
        <h5>sda</h5>
    </div>);
}
export default Filtro;