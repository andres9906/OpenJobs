
import React from 'react'

function InfoU(){
    return(<h1>Usuario</h1>);
}
export default InfoU;