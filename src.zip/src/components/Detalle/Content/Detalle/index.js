import React from 'react';
import ListGroup from 'react-bootstrap/ListGroup';
import  Pagination from 'react-bootstrap/Pagination';
import Button from 'react-bootstrap/Button';
import ListGroupItem from 'react-bootstrap/ListGroupItem';
function Detalle(){
  
    return(
       
    <div className="detalle">
     
<h1>Titulo</h1>
<br/>
<br/>
<p>Lorem ipsum dolor sit amet, bibendum dui in vitae. Arcu magna libero vehicula nunc vel sociosqu. Purus rhoncus sem odio scelerisque viverra, tempus libero justo, duis fringilla gravida lacinia nulla potenti, ante scelerisque, elementum at vitae tincidunt etiam justo. Ullamcorper turpis dui dui tempus, sed fringilla aenean fusce nulla eu nec, varius sem nullam. Est a lacinia, vestibulum neque id pellentesque magna sagittis nulla, ac libero gravida viverra dignissim sed. Pede arcu tellus, pellentesque repellat eget est dolor, condimentum amet. Sed quisque, ut quis, magna ac in aptent faucibus, montes interdum sapien urna vehicula, morbi sed montes turpis volutpat nullam vitae. Maecenas sed nunc ac ac scelerisque ridiculus, sed feugiat duis nulla, lobortis non massa non sollicitudin blandit magna.

Ante elementum consequat gravida nulla donec. Ut eleifend volutpat, semper et urna nulla posuere, hendrerit ligula venenatis bibendum turpis, pellentesque et vestibulum elit, pretium convallis. Urna odio eros non elit, mi interdum ipsum, morbi tortor nobis sed, posuere sapien nulla praesent sem eget, integer at arcu neque sit. Nibh donec aliquet lacus id. Ultricies praesent habitant feugiat, sodales maiores sapien tristique, maecenas condimentum id iaculis a nibh eu, eu hymenaeos quis in sed, rutrum quis. Nostrum ac lacus felis elementum, lacus malesuada donec feugiat elementum dui lorem. Sed bibendum ullamcorper pede ut est vel, donec ridiculus porttitor suspendisse nibh nibh, urna laboriosam nibh ac.</p>

    </div>
    );
  
}

export default Detalle;
