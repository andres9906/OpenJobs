import React from 'react';
import Home from './Home';
import Search from './Search';
import Detail from './Detalle'
import 'bootstrap/dist/css/bootstrap.min.css';

class App extends React.Component {
  render(){
    return(
    <main className="main">
      <Detail/>

    </main>);
  }
}

export default App;
