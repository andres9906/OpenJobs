import React from 'react';

function LeftSideBar(){

    return(<div className="left-sidebar" style={{height:'100vh'}}>
<h1>Tu cuenta</h1>
<ul>
   
    <li><><a href="/Update">Actualizar</a></></li>


</ul>

    </div>);
}
export default LeftSideBar;