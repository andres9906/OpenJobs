import React from'react';
function About(){
    return(<div class="main">

        <h1>Integrantes</h1>
        <hr></hr>
        Andres Perez
        <br></br>
        Camilo Pacheco 
        <br></br>
        Brandon Gonzalez
        <br></br>
        <h1>Modulos instaldos</h1>
        <hr></hr>
        <ul>
            <li>
            "@fortawesome/fontawesome-svg-core": "^1.2.25"
            </li>
            <li>
            "@fortawesome/free-solid-svg-icons": "^5.11.2",
            </li>
            <li> "@fortawesome/react-fontawesome": "^0.1.5"</li>
            <li> "bootstrap": "^4.3.1"</li>
            <li>"firebase": "^7.1.0",</li>
            <li>"node-sass": "^4.12.0",</li>
            <li>"materialize-css": "^1.0.0",</li>
            <li>"react-router-dom": "^5.1.2",</li>
        </ul>
        
  
   
   
    
 
    
    

    

    </div>);
}
export default About