import React from 'react';
import LeftSideBar from './LeftsideBar';
import Trabajo from './Trabajos'
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import Container from 'react-bootstrap/Container';

function Usuario() {
    return (<div className="mai">

        <Row >
            <Col style={{ height: 'auto' }}>

                <LeftSideBar />

            </Col>
            <Col >
                <Row>
                    <h2>Trabajos publicados</h2>
                    <br/>
                    <hr></hr>
                    <hr></hr>


                    <Trabajo></Trabajo>
                </Row>

                <Row>
                    <h2>Trabajos aceptados</h2>
                    <hr ></hr>
                    <Trabajo></Trabajo>
                </Row>
            </Col>
            <Col>
                <h1>Usuario</h1></Col>
        </Row>
    </div>);
}
export default Usuario;