import React from 'react';
import ListGroup from 'react-bootstrap/ListGroup';
import Media from 'react-media';

import {
  withRouter
  } from 'react-router-dom'
  
  
import Button from 'react-bootstrap/Button';
function Trabajo (props){
  const {history}=props; 
  
    return(
      <ListGroup style={{paddingTop:'100px'}}>
      <Media queries={{
   
   small: " (max-width: 999px)",
   medium: "(min-width: 1000px) and (max-width: 1418px)",
   large: "(min-width: 1419px)"
 }}>
   {matches => (
     <>
       {matches.small && <ListGroup.Item style={{width:'400px'}}><h4>Titulo</h4><br/><p>	
A unique identifier for the Component, the eventKey makes it distinguishable from others in a set. Similar to React's key prop, in that it only needs to be unique amongst the Components siblings, not globally.<br/></p>
<div class="but" style={{paddingLeft:'250px',paddingTop:'30px'}}><Button variant="outline-info" onClick={() =>history.push('/Search/Detail')}>Ver mas</Button>
</div>
</ListGroup.Item>}
       {matches.medium &&   <ListGroup.Item style={{width:'750px'}}><h4>Titulo</h4><br/><p>	
A unique identifier for the Component, the eventKey makes it distinguishable from others in a set. Similar to React's key prop, in that it only needs to be unique amongst the Components siblings, not globally.<br/></p>
<div class="but" style={{paddingLeft:'600px',paddingTop:'30px'}}><Button variant="outline-info" onClick={() =>history.push('/Search/Detail')}>Ver mas</Button>
</div>
</ListGroup.Item>}
       
       {matches.large &&  <ListGroup.Item style={{width:'800px'}}><h4> Titulo</h4><br/><p>	
A unique identifier for the Component, the eventKey makes it distinguishable from others in a set. Similar to React's key prop, in that it only needs to be unique amongst the Components siblings, not globally.<br/></p>
<div class="but" style={{paddingLeft:'650px',paddingTop:'30px'}}><Button variant="outline-info" onClick={() =>history.push('/Search/Detail')}>Ver mas</Button>
</div>
</ListGroup.Item>}
    </>
   )}
 </Media>
    

</ListGroup>

    );
  
}

export default withRouter(Trabajo);
