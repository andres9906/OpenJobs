import React from 'react';

function LeftSideBar(){

    return(<main className="left-sidebar">
<h1>Tu cuenta</h1>
<ul>
    <li><><a href="/Search">Trabajo publicados</a></></li>
    <li><><a href="/Publicar">Publicar trabajos</a></></li>
    <li><><a href="/Update">Actualizar</a></></li>


</ul>

    </main>);
}
export default LeftSideBar;