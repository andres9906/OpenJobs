import React from 'react';

function LeftSideBar(){

    return(<main className="leftSideBar"></main>);
}
export default LeftSideBar();