import React from 'react';

import Section from './Section';
import 'bootstrap/dist/css/bootstrap.min.css';

function Home (){
  
    return(
    <div className="ma" >

      <Section/>

    </div>);
  
}

export default Home;
