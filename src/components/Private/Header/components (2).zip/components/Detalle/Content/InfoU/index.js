
import React, { useState, useEffect } from 'react'
import ListGroup from 'react-bootstrap/ListGroup';
import { db } from './../../../../config/firebase'
function InfoU(props) {

    const [resultado, setResultado] = React.useState([]);
    useEffect(() => {
        var url = new URL(window.location.href);

        var d = url.searchParams.get("Trabajo")
        const fetchData = async () => {

            const data = await db.collection("Trabajos").doc(d).get();
            setResultado({ ...data.data(), id: data.id });
        };
        fetchData();


    }, []);
    return (<div className="Algonuevo">
       
        {props.auth ?
        <>
 < h6 > {resultado.Email}</h6>
            
            <ListGroup style={{ height: '300px', overflow: 'auto' }} >
                <ListGroup.Item>Cras justo odio</ListGroup.Item>
                <ListGroup.Item>Nombre <button>aceptar</button></ListGroup.Item>
                <ListGroup.Item>Morbi leo risus</ListGroup.Item>
                <ListGroup.Item>Porta ac consectetur ac</ListGroup.Item>
                <ListGroup.Item>Vestibulum at eros</ListGroup.Item>
                <ListGroup.Item>Cras justo odio</ListGroup.Item>
                <ListGroup.Item>Dapibus ac facilisis in</ListGroup.Item>
                <ListGroup.Item>Morbi leo risus</ListGroup.Item>
                <ListGroup.Item>Porta ac consectetur ac</ListGroup.Item>
                <ListGroup.Item>Vestibulum at eros</ListGroup.Item>
            </ListGroup >
            </>
            :    < h6 > {resultado.Email}</h6>}</div >);
}
export default InfoU;