
import React from 'react'

function Filtro(){
    return(<div class="Filtrado">
        <hr class="linea"></hr>
        <h5>Filtros</h5>
        <hr class="linea"></hr>
    </div>);
}
export default Filtro;