
import React, { useState, useEffect } from 'react';
import { db } from './../../../../config/firebase';

function Detalle() {
    const [resultado, setResultado] = React.useState([]);
    useEffect(() => {
        var url = new URL(window.location.href);

        var d = url.searchParams.get("Trabajo")
        const fetchData = async () => {

            const data = await db.collection("Trabajos").doc(d).get();
            setResultado({ ...data.data(), id: data.id });
        };
        fetchData();


    }, []);
    console.log(resultado)
    return (

        <div className="detalle">

            <h1>{resultado.Nombre}</h1>
         
    <p><h3>Descripcion:</h3>{resultado.Descripcion} <br></br><h3>Sueldo:</h3>{resultado.Sueldo}</p>

        </div>
    );

}

export default Detalle;
