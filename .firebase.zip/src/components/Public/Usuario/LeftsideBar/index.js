import React from 'react';

function LeftSideBar(){

    return(<div className="left-sidebar" >
<h1>Tu cuenta</h1>
<ul>
    <li><><a href="/Search">Trabajo publicados</a></></li>
    <li><><a href="/Publicar">Publicar trabajos</a></></li>


</ul>

    </div>);
}
export default LeftSideBar;