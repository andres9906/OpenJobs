import React from "react";
function Footer(){

    return(<div className="Footer">


    </div>);
}
export default Footer;