import React, { useState, useEffect } from 'react';

import Content from './Content';
import 'bootstrap/dist/css/bootstrap.min.css';


function Search() {






  return (
    <div className="Content">
 
      <Content />

    </div>);

}

export default Search;
